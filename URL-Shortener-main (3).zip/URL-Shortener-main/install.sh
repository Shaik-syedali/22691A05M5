# Navigate to the client folder
cd client

# Install client dependencies
npm install

# Return to the root folder
cd ..

# Navigate to the server folder
cd server

# Install server dependencies
npm install

# Return to the root folder
cd ..